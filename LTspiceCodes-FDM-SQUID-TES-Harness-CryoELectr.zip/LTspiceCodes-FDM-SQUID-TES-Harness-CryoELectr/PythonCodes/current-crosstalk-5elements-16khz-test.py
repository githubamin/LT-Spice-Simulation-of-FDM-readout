#RMS + Complex current cross talk
# %matplotlib inline      run it in the console
import numpy as np
import matplotlib.pyplot as plt
import io
import cmath

#Magnitudes and phases of currents  except Ites3, the resonance one at 1.032MHz    crosstalk-P05-1.064MHz-16khz-setup-2nd
#.ac lin 5000 0.9meg 1.2meg
#Mags=np.array([1.8,1.7,0.9,0.84]  )


#crosstalk-P05-1.064MHz-16khz-setup-2nd   .ac list 1.0315meg   SINE(0 1 1.0315meg)
Mags=np.array([1.8E-6,1.66E-6,8.9E-7,0.84E-6]  )                                                                #Ites1-Ites5
              


Phase_deg=np.array([-112,60.38,-113.86,62] )                                                                                                   #P Ites1-Ites5
                    

Phase_rad=cmath.pi/180 * Phase_deg
compleks=[1+1j,0,0,0,0]
         
for i in range(0,4) :
 compleks[i]=cmath.rect(Mags[i],Phase_rad[i])

realm=np.real(compleks)
im=np.imag(compleks)

sumreal=np.sum(realm)
sumimag=np.sum(im)
icrosstalk=cmath.polar(sumreal+1j*sumimag)
Ites=2.318E-5
crosstalk=icrosstalk[0]/Ites *100  #percentage

#I(R-tes5):	mag:  0.0815818 phase:    88.0832° 	device_current
#I(R-tes4):	mag:   0.164138 phase:    86.1413° 	device_current
#I(R-tes3):	mag:    2.43902 phase: -1.29813e-005° 	device_current    REF
#I(R-tes2):	mag:   0.166691 phase:   -86.0812° 	device_current
#I(R-tes1):	mag:  0.0841483 phase:   -88.0229° 	device_current
