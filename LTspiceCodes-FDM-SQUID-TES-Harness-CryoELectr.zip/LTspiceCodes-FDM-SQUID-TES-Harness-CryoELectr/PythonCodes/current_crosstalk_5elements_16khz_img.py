#RMS + Complex current cross talk
# %matplotlib inline      run it in the console
import numpy as np
import matplotlib.pyplot as plt
import io
import cmath

#Magnitudes and phases of currents  except Ites3, the resonance one at 1.03148MHz   5000 points Lin3nH  crosstalk-P05-1.064MHz-16khz-setup
realm=np.array([3.62203212180665e-007,-6.69922804709590e-007,8.23432354684242e-007,3.91739421089065e-007]  )                                                               #Ites1-Ites5
              


imge=np.array([-8.22478019274114e-007,-1.68094489900144e-006,1.45453829657718e-006,7.47334676905705e-007] )                                                                                                   #P Ites1-Ites5
                    

#Phase_rad=cmath.pi/180 * Phase_deg
compleks=[1+1j,0,0,0]
rmsc=[0,0,0,0]         
for i in range(0,4) :
 compleks[i]=realm[i]+1j*imge[i]
 rmsc[i]=np.abs(compleks[i])

sqrms=np.square(rmsc)
sumsqr=np.sum(sqrms)
leakage_rms=(sumsqr)**0.5
Ires=np.abs(2.318e-5-1.973e-007j)
careerleak=leakage_rms/Ires *100
print("Crosstalk=",careerleak,"%, (Irms  career leakage )")
sumcompleks=np.sum(compleks)
Isum=np.abs(sumcompleks)
Isum/Ires*100

#Freq.	I(L3)
#1.00000000000000e+006	2.72618177350174e-003,8.14964010461508e-002
#1.01600000000000e+006	1.10433177826642e-002,1.63746010587365e-001
                                                                           #1.03200000000000e+006	2.43901837295485e+000,-5.52599231515663e-007
#1.04800000000000e+006	1.13894594390524e-002,-1.66281142818887e-001
#1.06400000000000e+006	2.90045356058479e-003,-8.40584575201990e-002
