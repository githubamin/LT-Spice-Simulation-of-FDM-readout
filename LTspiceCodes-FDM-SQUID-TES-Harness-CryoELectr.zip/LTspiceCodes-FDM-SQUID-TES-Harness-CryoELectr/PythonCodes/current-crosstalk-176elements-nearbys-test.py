#RMS + Complex current cross talk
# %matplotlib inline      run it in the console
import numpy as np
import matplotlib.pyplot as plt
import io
import cmath

#Magnitudes and phases of currents  except Ites3, the resonance one at 1.032MHz    crosstalk-P05-1.064MHz-16khz-setup-2nd
#.ac lin 5000 0.9meg 1.2meg
#Mags=np.array([1.8,1.7,0.9,0.84]  )


#crosstalk-P05-1.064MHz-16khz-setup-2nd   .ac list 1.0315meg   SINE(0 1 1.0315meg)
Mags=np.array([8.17859e-007,1.57831e-006,1.84898e-006,8.91145e-007]  )                                                                #Ites1-Ites5
              


Phase_deg=np.array([31.28, 29.56, -142.69, -144.86] )                                                                                                   #P Ites1-Ites5
                    

Phase_rad=cmath.pi/180 * Phase_deg
compleks=[1+1j,0,0,0,0]
         
for i in range(0,4) :
 compleks[i]=cmath.rect(Mags[i],Phase_rad[i])

realm=np.real(compleks)
im=np.imag(compleks)

sumreal=np.sum(realm)
sumimag=np.sum(im)
icrosstalk=cmath.polar(sumreal+1j*sumimag)
Ites=1.668E-5
crosstalk=icrosstalk[0]/Ites *100  #percentage

#I(L171):	mag: 8.17859e-007 phase:    31.2832° 	device_current
#I(L170):	mag: 1.57831e-006 phase:     29.565° 	device_current
#I(L169):	mag: 1.6678e-005 phase:   -7.93622° 	device_current
#I(L168):	mag: 1.84898e-006 phase:   -142.694° 	device_current
#I(L167):	mag: 8.91145e-007 phase:   -144.859° 	device_current
