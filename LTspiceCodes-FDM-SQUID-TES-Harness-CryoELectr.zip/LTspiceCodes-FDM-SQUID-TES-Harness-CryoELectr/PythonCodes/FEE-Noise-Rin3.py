#RMS + Complex current cross talk
# %matplotlib inline      run it in the console
import numpy as np
import matplotlib.pyplot as plt
import io
import cmath

Vdem=173e-9
gain=5000
In=5.4e-12
Vn=315e-12
Rs=100
Kb=1.38e-23
T=1.3
Rin=129#[88, 129]
#Rin=np.array(Rin)
Rsa=[ 10, 20,30, 40, 50, 100, 150, 200, 250, 300, 350,400]
Rsa=np.array(Rsa)


Vmeasure=(    Vdem**2+  gain**2*(   (In**2* Rsa**2+Vn**2+(4*Kb*T*Rsa))*(Rin/(Rin+Rsa))**2   )    )**0.5
Vmeasure
print("Vmeasurement=", Vmeasure)
Noisein=((In**2* Rsa**2+Vn**2+(4*Kb*T*Rsa))*(Rin/(Rin+Rsa))**2)**0.5
print("Noisein=", Noisein)

plt.plot(Rsa,Vmeasure/2)
plt.grid()

Rin=40
Vmeasure=(    Vdem**2+  gain**2*(   (In**2* Rsa**2+Vn**2+(4*Kb*T*Rsa))*(Rin/(Rin+Rsa))**2   )    )**0.5
Noisein=((In**2* Rsa**2+Vn**2+(4*Kb*T*Rsa))*(Rin/(Rin+Rsa))**2)**0.5
plt.plot(Rsa,Vmeasure/2)

Rin=88
Vmeasure=(    Vdem**2+  gain**2*(   (In**2* Rsa**2+Vn**2+(4*Kb*T*Rsa))*(Rin/(Rin+Rsa))**2   )    )**0.5
Noisein=((In**2* Rsa**2+Vn**2+(4*Kb*T*Rsa))*(Rin/(Rin+Rsa))**2)**0.5
plt.plot(Rsa,Vmeasure/2)
plt.show()
