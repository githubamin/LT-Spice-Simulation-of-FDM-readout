#RMS + Complex current cross talk
# %matplotlib inline      run it in the console
import numpy as np
import matplotlib.pyplot as plt
import io
import cmath

#Magnitudes and phases of currents  except IL169, the resonance one at 3.716MHz 
Mags=np.array([2.31147e-007, 2.69931e-007, 3.24076e-007, 4.04957e-007, 5.38859e-007, 8.03286e-007,  1.56975e-006,                                                                #IL176-IL170
               1.73988e-006, 8.51353e-007, 5.64233e-007, 4.22382e-007, 3.37821e-007, 2.81677e-007, 2.41688e-007, 2.11759e-007, 1.88519e-007 ,                                    #IL168-IL160
               1.69952e-007, 1.54777e-007, 1.42142e-007, 1.31461e-007, 1.22311e-007, 1.14387e-007, 1.07458e-007, 1.01347e-007, 9.59176e-008, 9.10624e-008,                       #IL159-IL150                            
               8.66948e-008, 8.2745e-008, 7.91559e-008, 7.58803e-008,  7.2879e-008,  7.01191e-008, 6.75725e-008, 6.52157e-008,6.30281e-008, 6.09923e-008,                        #IL149-IL140
			   5.90931e-008, 5.73173e-008, 5.56532e-008, 5.40907e-008, 5.26208e-008, 5.12356e-008, 	4.99281e-008, 4.86918e-008, 4.75212e-008, 4.64112e-008,  		             #IL139-IL130
               4.53574e-008, 4.43555e-008, 4.34018e-008, 4.24931e-008, 4.16261e-008, 4.07982e-008,  4.00069e-008, 3.92497e-008, 3.85245e-008, 3.78294e-008,                      #IL129-IL120
               3.71625e-008, 3.65223e-008, 3.59072e-008, 3.53157e-008, 3.47465e-008, 3.41985e-008, 3.36705e-008, 3.31615e-008, 3.26704e-008, 3.21963e-008,                       #IL119-IL110  
               3.17385e-008, 3.12961e-008, 3.08683e-008, 3.04546e-008, 3.00541e-008, 2.96664e-008, 2.92908e-008, 2.89268e-008, 2.85739e-008, 2.82315e-008,                       #IL109-IL100
               2.78994e-008, 2.75769e-008, 2.72638e-008, 2.69596e-008, 2.6664e-008,  2.63767e-008, 2.60972e-008, 2.58254e-008 , 2.55609e-008,2.53035e-008,                       #IL99-IL90
               2.50528e-008, 2.48087e-008, 2.45708e-008, 2.43391e-008, 2.41132e-008, 2.38929e-008, 2.36781e-008, 2.34686e-008, 2.32642e-008, 2.30648e-008,                       #IL89-IL80 
               2.28701e-008, 2.268e-008,   2.24943e-008, 2.2313e-008,  2.21359e-008, 2.19628e-008, 2.17937e-008, 2.16284e-008, 2.14668e-008 ,2.13088e-008,                       #IL79-IL70
               2.11542e-008, 2.10031e-008,2.08552e-008,  2.07106e-008, 2.0569e-008, 2.04305e-008, 2.02949e-008, 2.01621e-008, 2.00322e-008, 1.99049e-008,                        #IL69-IL60
               1.97803e-008, 1.96582e-008, 1.95387e-008,1.94216e-008,1.93068e-008 ,1.91944e-008, 1.90842e-008, 1.89763e-008,1.88705e-008, 1.87668e-008,                          #IL59-IL50
               1.86651e-008, 1.85654e-008, 1.84677e-008, 1.8372e-008, 1.8278e-008,1.81859e-008,  1.80956e-008, 1.80071e-008, 1.79202e-008,1.7835e-008,                           #IL49-IL40
               1.77515e-008, 1.76695e-008, 1.75891e-008,1.75103e-008 ,1.74329e-008,1.7357e-008,1.72826e-008, 1.72096e-008   ,1.7138e-008, 1.70677e-008,                          #IL39-IL30 
               1.69987e-008, 1.69311e-008, 1.68648e-008,1.67997e-008,1.67358e-008, 1.66732e-008, 1.66118e-008,1.65515e-008, 1.64924e-008, 1.64344e-008,                          #IL29-IL20
               1.63775e-008, 1.63217e-008,1.6267e-008, 1.62134e-008, 1.61608e-008, 1.61092e-008,1.60586e-008,1.6009e-008, 1.59604e-008, 1.59127e-008,                            #IL19-IL10
               1.5866e-008, 1.58203e-008,1.57754e-008,1.57314e-008, 1.56884e-008, 1.56462e-008,1.56049e-008, 1.55644e-008,1.55248e-008                                           #IL9-IL1  
			   ])              


Phase_deg=np.array([ 84.4556, 84.3652,84.2391, 84.0507, 83.7388, 83.1228, 81.3356,    #P IL176-IL170
                    -90.9507, -93.023, -93.692, -94.0224,-94.2193, -94.3501, -94.4432, -94.5129,-94.5671, #P IL168-IL160    
                    -94.6103, -94.6457, -94.6751,-94.7, -94.7213, -94.7397, -94.7559, -94.7701,-94.7827,-94.794,#P IL159-IL150      
                    -94.8042,  -94.8134,  -94.8218, -94.8294, -94.8364,-94.8428, -94.8487, -94.8542,-94.8593,-94.8641,#P IL149-IL140    
                    -94.8685, -94.8726, -94.8765, -94.8801,-94.8836, -94.8868, -94.8898, -94.8927,-94.8954, -94.898, #P IL139-IL130
                    -94.9005, -94.9028, -94.905, -94.9072, -94.9092,-94.9111,-94.9129,  -94.9147,-94.9164, -94.918, #P IL129-IL120  
                    -94.9196, -94.9211, -94.9225, -94.9239, -94.9252, -94.9265,-94.9277, -94.9289, -94.93, -94.9311, #P IL119-IL110    
                    -94.9322, -94.9332, -94.9342, -94.9352,  -94.9361, -94.937,-94.9379, -94.9388, -94.9396,-94.9404, #P IL109-IL100 
                    -94.9411, -94.9419, -94.9426, -94.9433, -94.944, -94.9447, -94.9453, -94.946, -94.9466,-94.9472,  #P IL99-IL90
                    -94.9478, -94.9483, -94.9489,-94.9494, -94.95, -94.9505, -94.951, -94.9515, -94.9519,  -94.9524, #P IL89-IL80 
                    -94.9529, -94.9533, -94.9537, -94.9542, -94.9546,  -94.955,-94.9554, -94.9557, -94.9561, -94.9565,  #P IL79-IL70   
                    -94.9569, -94.9572, -94.9576, -94.9579, -94.9582, -94.9585, -94.9589, -94.9592,-94.9595, -94.9598, #P IL69-IL60 
                    -94.9601, -94.9603, -94.9606, -94.9609,-94.9612, -94.9614,-94.9617,  -94.9619,  -94.9622,-94.9624, #P IL59-IL50  
                    -94.9627, -94.9629, -94.9631, -94.9633, -94.9636, -94.9638, -94.964,-94.9642,  -94.9644, -94.9646, #P IL49-IL40
                    -94.9648, -94.965,  -94.9652,-94.9653, -94.9655,  -94.9657,-94.9659,  -94.966,-94.9662, -94.9664, #P IL39-IL30 
                    -94.9665,-94.9667,  -94.9668,-94.967, -94.9671,-94.9673, -94.9674, -94.9676, -94.9677, -94.9678,  #P IL29-IL20
                    -94.968, -94.9681, -94.9682, -94.9684,  -94.9685, -94.9686,-94.9687, -94.9688, -94.9689, -94.9691, #P IL19-IL10
                    -94.9692, -94.9693, -94.9694, -94.9695, -94.9696, -94.9697, -94.9698,   -94.9699,  -94.97           #P IL9-IL1
 ])                                                                


Phase_rad=cmath.pi/180 * Phase_deg
compleks=[1+1j,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
          0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
for i in range(0,175) :
 compleks[i]=cmath.rect(Mags[i],Phase_rad[i])

realm=np.real(compleks)
im=np.imag(compleks)

sumreal=np.sum(realm)
sumimag=np.sum(im)
icrosstalk=cmath.polar(sumreal+1j*sumimag)
# I(L169):	mag: 1.98171e-005 phase:    31.3347° 	device_current
#  icrosstalk(6.192293178430758e-06, -1.6010828122018845)
#crosstalk= real(icrosstalk)/real(Il169) *100 %    31.24%
#complex I

#Irms
#Isq=Mags*Mags Irms=(np.sum(Isq))**0.5
#crosstalk rms = 

#taken from LTSpice ISC-3.716MHz   

#frequency:	3.716e+006	Hz


#I(L176):	mag: 2.31147e-007 phase:    84.4556° 	device_current
#I(L175):	mag: 2.69931e-007 phase:    84.3652° 	device_current
#I(L174):	mag: 3.24076e-007 phase:    84.2391° 	device_current
#I(L173):	mag: 4.04957e-007 phase:    84.0507° 	device_current
#I(L172):	mag: 5.38859e-007 phase:    83.7388° 	device_current
#I(L171):	mag: 8.03286e-007 phase:    83.1228° 	device_current
#I(L170):	mag: 1.56975e-006 phase:    81.3356° 	device_current

#I(L169):	mag: 1.98171e-005 phase:    31.3347° 	device_current
# I_resonance


#I(L168):	mag: 1.73988e-006 phase:   -90.9507° 	device_current
#I(L167):	mag: 8.51353e-007 phase:    -93.023° 	device_current
#I(L166):	mag: 5.64233e-007 phase:    -93.692° 	device_current
#I(L165):	mag: 4.22382e-007 phase:   -94.0224° 	device_current
#I(L164):	mag: 3.37821e-007 phase:   -94.2193° 	device_current
#I(L163):	mag: 2.81677e-007 phase:   -94.3501° 	device_current
#I(L162):	mag: 2.41688e-007 phase:   -94.4432° 	device_current
#I(L161):	mag: 2.11759e-007 phase:   -94.5129° 	device_current
#I(L160):	mag: 1.88519e-007 phase:   -94.5671° 	device_current

#I(L159):	mag: 1.69952e-007 phase:   -94.6103° 	device_current
#I(L158):	mag: 1.54777e-007 phase:   -94.6457° 	device_current
#I(L157):	mag: 1.42142e-007 phase:   -94.6751° 	device_current
#I(L156):	mag: 1.31461e-007 phase:      -94.7° 	device_current
#I(L155):	mag: 1.22311e-007 phase:   -94.7213° 	device_current
#I(L154):	mag: 1.14387e-007 phase:   -94.7397° 	device_current
#I(L153):	mag: 1.07458e-007 phase:   -94.7559° 	device_current
#I(L152):	mag: 1.01347e-007 phase:   -94.7701° 	device_current
#I(L151):	mag: 9.59176e-008 phase:   -94.7827° 	device_current
#I(L150):	mag: 9.10624e-008 phase:    -94.794° 	device_current

#I(L149):	mag: 8.66948e-008 phase:   -94.8042° 	device_current
#I(L148):	mag: 8.2745e-008 phase:   -94.8134° 	device_current
#I(L147):	mag: 7.91559e-008 phase:   -94.8218° 	device_current
#I(L146):	mag: 7.58803e-008 phase:   -94.8294° 	device_current
#I(L145):	mag: 7.2879e-008 phase:   -94.8364° 	device_current
#I(L144):	mag: 7.01191e-008 phase:   -94.8428° 	device_current
#I(L143):	mag: 6.75725e-008 phase:   -94.8487° 	device_current
#I(L142):	mag: 6.52157e-008 phase:   -94.8542° 	device_current
#I(L141):	mag: 6.30281e-008 phase:   -94.8593° 	device_current
#I(L140):	mag: 6.09923e-008 phase:   -94.8641° 	device_current


#I(L139):	mag: 5.90931e-008 phase:   -94.8685° 	device_current
#I(L138):	mag: 5.73173e-008 phase:   -94.8726° 	device_current
#I(L137):	mag: 5.56532e-008 phase:   -94.8765° 	device_current
#I(L136):	mag: 5.40907e-008 phase:   -94.8801° 	device_current
#I(L135):	mag: 5.26208e-008 phase:   -94.8836° 	device_current
#I(L134):	mag: 5.12356e-008 phase:   -94.8868° 	device_current
#I(L133):	mag: 4.99281e-008 phase:   -94.8898° 	device_current
#I(L132):	mag: 4.86918e-008 phase:   -94.8927° 	device_current
#I(L131):	mag: 4.75212e-008 phase:   -94.8954° 	device_current
#I(L130):	mag: 4.64112e-008 phase:    -94.898° 	device_current

#I(L129):	mag: 4.53574e-008 phase:   -94.9005° 	device_current
#I(L128):	mag: 4.43555e-008 phase:   -94.9028° 	device_current
#I(L127):	mag: 4.34018e-008 phase:    -94.905° 	device_current
#I(L126):	mag: 4.24931e-008 phase:   -94.9072° 	device_current
#I(L125):	mag: 4.16261e-008 phase:   -94.9092° 	device_current
#I(L124):	mag: 4.07982e-008 phase:   -94.9111° 	device_current
#I(L123):	mag: 4.00069e-008 phase:   -94.9129° 	device_current
#I(L122):	mag: 3.92497e-008 phase:   -94.9147° 	device_current
#I(L121):	mag: 3.85245e-008 phase:   -94.9164° 	device_current
#I(L120):	mag: 3.78294e-008 phase:    -94.918° 	device_current

#I(L119):	mag: 3.71625e-008 phase:   -94.9196° 	device_current
#I(L118):	mag: 3.65223e-008 phase:   -94.9211° 	device_current
#I(L117):	mag: 3.59072e-008 phase:   -94.9225° 	device_current
#I(L116):	mag: 3.53157e-008 phase:   -94.9239° 	device_current
#I(L115):	mag: 3.47465e-008 phase:   -94.9252° 	device_current
#I(L114):	mag: 3.41985e-008 phase:   -94.9265° 	device_current
#I(L113):	mag: 3.36705e-008 phase:   -94.9277° 	device_current
#I(L112):	mag: 3.31615e-008 phase:   -94.9289° 	device_current
#I(L111):	mag: 3.26704e-008 phase:     -94.93° 	device_current
#I(L110):	mag: 3.21963e-008 phase:   -94.9311° 	device_current

#I(L109):	mag: 3.17385e-008 phase:   -94.9322° 	device_current
#I(L108):	mag: 3.12961e-008 phase:   -94.9332° 	device_current
#I(L107):	mag: 3.08683e-008 phase:   -94.9342° 	device_current
#I(L106):	mag: 3.04546e-008 phase:   -94.9352° 	device_current
#I(L105):	mag: 3.00541e-008 phase:   -94.9361° 	device_current
#I(L104):	mag: 2.96664e-008 phase:    -94.937° 	device_current
#I(L103):	mag: 2.92908e-008 phase:   -94.9379° 	device_current
#I(L102):	mag: 2.89268e-008 phase:   -94.9388° 	device_current
#I(L101):	mag: 2.85739e-008 phase:   -94.9396° 	device_current
#I(L100):	mag: 2.82315e-008 phase:   -94.9404° 	device_current

#I(L99):	mag: 2.78994e-008 phase:   -94.9411° 	device_current
#I(L98):	mag: 2.75769e-008 phase:   -94.9419° 	device_current
#I(L97):	mag: 2.72638e-008 phase:   -94.9426° 	device_current
#I(L96):	mag: 2.69596e-008 phase:   -94.9433° 	device_current
#I(L95):	mag: 2.6664e-008 phase:    -94.944° 	device_current
#I(L94):	mag: 2.63767e-008 phase:   -94.9447° 	device_current
#I(L93):	mag: 2.60972e-008 phase:   -94.9453° 	device_current
#I(L92):	mag: 2.58254e-008 phase:    -94.946° 	device_current
#I(L91):	mag: 2.55609e-008 phase:   -94.9466° 	device_current
#I(L90):	mag: 2.53035e-008 phase:   -94.9472° 	device_current

#I(L89):	mag: 2.50528e-008 phase:   -94.9478° 	device_current
#I(L88):	mag: 2.48087e-008 phase:   -94.9483° 	device_current
#I(L87):	mag: 2.45708e-008 phase:   -94.9489° 	device_current
#I(L86):	mag: 2.43391e-008 phase:   -94.9494° 	device_current
#I(L85):	mag: 2.41132e-008 phase:     -94.95° 	device_current
#I(L84):	mag: 2.38929e-008 phase:   -94.9505° 	device_current
#I(L83):	mag: 2.36781e-008 phase:    -94.951° 	device_current
#I(L82):	mag: 2.34686e-008 phase:   -94.9515° 	device_current
#I(L81):	mag: 2.32642e-008 phase:   -94.9519° 	device_current
#I(L80):	mag: 2.30648e-008 phase:   -94.9524° 	device_current

#I(L79):	mag: 2.28701e-008 phase:   -94.9529° 	device_current
#I(L78):	mag: 2.268e-008 phase:   -94.9533° 	device_current
#I(L77):	mag: 2.24943e-008 phase:   -94.9537° 	device_current
#I(L76):	mag: 2.2313e-008 phase:   -94.9542° 	device_current
#I(L75):	mag: 2.21359e-008 phase:   -94.9546° 	device_current
#I(L74):	mag: 2.19628e-008 phase:    -94.955° 	device_current
#I(L73):	mag: 2.17937e-008 phase:   -94.9554° 	device_current
#I(L72):	mag: 2.16284e-008 phase:   -94.9557° 	device_current
#I(L71):	mag: 2.14668e-008 phase:   -94.9561° 	device_current
#I(L70):	mag: 2.13088e-008 phase:   -94.9565° 	device_current

#I(L69):	mag: 2.11542e-008 phase:   -94.9569° 	device_current
#I(L68):	mag: 2.10031e-008 phase:   -94.9572° 	device_current
#I(L67):	mag: 2.08552e-008 phase:   -94.9576° 	device_current
#I(L66):	mag: 2.07106e-008 phase:   -94.9579° 	device_current
#I(L65):	mag: 2.0569e-008 phase:   -94.9582° 	device_current
#I(L64):	mag: 2.04305e-008 phase:   -94.9585° 	device_current
#I(L63):	mag: 2.02949e-008 phase:   -94.9589° 	device_current
#I(L62):	mag: 2.01621e-008 phase:   -94.9592° 	device_current
#I(L61):	mag: 2.00322e-008 phase:   -94.9595° 	device_current
#I(L60):	mag: 1.99049e-008 phase:   -94.9598° 	device_current

#I(L59):	mag: 1.97803e-008 phase:   -94.9601° 	device_current
#I(L58):	mag: 1.96582e-008 phase:   -94.9603° 	device_current
#I(L57):	mag: 1.95387e-008 phase:   -94.9606° 	device_current
#I(L56):	mag: 1.94216e-008 phase:   -94.9609° 	device_current
#I(L55):	mag: 1.93068e-008 phase:   -94.9612° 	device_current
#I(L54):	mag: 1.91944e-008 phase:   -94.9614° 	device_current
#I(L53):	mag: 1.90842e-008 phase:   -94.9617° 	device_current
#I(L52):	mag: 1.89763e-008 phase:   -94.9619° 	device_current
#I(L51):	mag: 1.88705e-008 phase:   -94.9622° 	device_current
#I(L50):	mag: 1.87668e-008 phase:   -94.9624° 	device_current

#I(L49):	mag: 1.86651e-008 phase:   -94.9627° 	device_current
#I(L48):	mag: 1.85654e-008 phase:   -94.9629° 	device_current
#I(L47):	mag: 1.84677e-008 phase:   -94.9631° 	device_current
#I(L46):	mag: 1.8372e-008 phase:   -94.9633° 	device_current
#I(L45):	mag: 1.8278e-008 phase:   -94.9636° 	device_current
#I(L44):	mag: 1.81859e-008 phase:   -94.9638° 	device_current
#I(L43):	mag: 1.80956e-008 phase:    -94.964° 	device_current
#I(L42):	mag: 1.80071e-008 phase:   -94.9642° 	device_current
#I(L41):	mag: 1.79202e-008 phase:   -94.9644° 	device_current
#I(L40):	mag: 1.7835e-008 phase:   -94.9646° 	device_current

#I(L39):	mag: 1.77515e-008 phase:   -94.9648° 	device_current
#I(L38):	mag: 1.76695e-008 phase:    -94.965° 	device_current
#I(L37):	mag: 1.75891e-008 phase:   -94.9652° 	device_current
#I(L36):	mag: 1.75103e-008 phase:   -94.9653° 	device_current
#I(L35):	mag: 1.74329e-008 phase:   -94.9655° 	device_current
#I(L34):	mag: 1.7357e-008 phase:   -94.9657° 	device_current
#I(L33):	mag: 1.72826e-008 phase:   -94.9659° 	device_current
#I(L32):	mag: 1.72096e-008 phase:    -94.966° 	device_current
#I(L31):	mag: 1.7138e-008 phase:   -94.9662° 	device_current
#I(L30):	mag: 1.70677e-008 phase:   -94.9664° 	device_current

#I(L29):	mag: 1.69987e-008 phase:   -94.9665° 	device_current
#I(L28):	mag: 1.69311e-008 phase:   -94.9667° 	device_current
#I(L27):	mag: 1.68648e-008 phase:   -94.9668° 	device_current
#I(L26):	mag: 1.67997e-008 phase:    -94.967° 	device_current
#I(L25):	mag: 1.67358e-008 phase:   -94.9671° 	device_current
#I(L24):	mag: 1.66732e-008 phase:   -94.9673° 	device_current
#I(L23):	mag: 1.66118e-008 phase:   -94.9674° 	device_current
#I(L22):	mag: 1.65515e-008 phase:   -94.9676° 	device_current
#I(L21):	mag: 1.64924e-008 phase:   -94.9677° 	device_current
#I(L20):	mag: 1.64344e-008 phase:   -94.9678° 	device_current

#I(L19):	mag: 1.63775e-008 phase:    -94.968° 	device_current
#I(L18):	mag: 1.63217e-008 phase:   -94.9681° 	device_current
#I(L17):	mag: 1.6267e-008 phase:   -94.9682° 	device_current
#I(L16):	mag: 1.62134e-008 phase:   -94.9684° 	device_current
#I(L15):	mag: 1.61608e-008 phase:   -94.9685° 	device_current
#I(L14):	mag: 1.61092e-008 phase:   -94.9686° 	device_current
#I(L13):	mag: 1.60586e-008 phase:   -94.9687° 	device_current
#I(L12):	mag: 1.6009e-008 phase:   -94.9688° 	device_current
#I(L11):	mag: 1.59604e-008 phase:   -94.9689° 	device_current
#I(L10):	mag: 1.59127e-008 phase:   -94.9691° 	device_current

#I(L9):	mag: 1.5866e-008 phase:   -94.9692° 	device_current
#I(L8):	mag: 1.58203e-008 phase:   -94.9693° 	device_current
#I(L7):	mag: 1.57754e-008 phase:   -94.9694° 	device_current
#I(L6):	mag: 1.57314e-008 phase:   -94.9695° 	device_current
#I(L5):	mag: 1.56884e-008 phase:   -94.9696° 	device_current
#I(L4):	mag: 1.56462e-008 phase:   -94.9697° 	device_current
#I(L3):	mag: 1.56049e-008 phase:   -94.9698° 	device_current
#I(L2):	mag: 1.55644e-008 phase:   -94.9699° 	device_current
#I(L1):	mag: 1.55248e-008 phase:     -94.97° 	device_current

#I(L-loom2):	mag: 2.88081e-006 phase:  -0.567535° 	device_current
#I(L-loom1):	mag: 0.00010288 phase:    179.917° 	device_current

#plt.plot(elem1,elem2)
#plt.grid()
#plt.show()
